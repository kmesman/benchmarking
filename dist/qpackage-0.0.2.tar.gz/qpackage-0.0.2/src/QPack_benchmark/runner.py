#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 16:55:12 2022

Run quantum algorithm using instrument coordinator
@author: koen
"""
import cast_to_QASM as qasm
import simulator_template as sim
import sim_device as sd
from quantify_scheduler.compilation import qcompile

import time
import numpy as np
import collections

# class necessary?


def timer(func, *args):
    start = time.time()
    res = func(*args)
    stop = time.time()
    runtime = stop-start
    return runtime, res

class algorithm_runner:
    """
    Operation flow of algorithm coordinator:
    init:
        initialize class variables
        set dummy ip --> add dummy ip to input ip
        determine if device is simulated
            --> configure simulated threshold
        start walltime timer
        add registered devices to IC
    run:
        compile schedule
        prepare IC
        run IC
        if simulated: run device simulation
        measure and post process
    """
    
    def __init__(self,
                 shots=100,
                 simulated=True,
                 simulate_res=True
):
        # general class variables
        self.shots = shots
        self.log = False #!!!
        self.simulate_res = simulate_res
        self.accessable_qubits = 0
        self.simulated = simulated
        self.hardware_runtime = {"initialization": 0, "compile": 0,
                                 "running": 0, "total": 0,
                                 "optimizer": 0, "post_processing": 0,
                                 "simulation": 0, "schedule": 0,
                                 "prepare": 0, "sched_run": 0}  # ns


    def run(self, sched, backend):
        """
        Runs the quantify schedule, optionally simulating the results if no
        quantum device is used.
        """
        # compile schedule
        comp_start = time.time_ns()
        compiled_sched = qcompile(
            sched, backend.device_config, backend.qblox_mapping)
        comp_stop = time.time_ns()
        sched_time = 0

        for item in compiled_sched["operation_dict"]:
            if self.log:
                print(item, compiled_sched["operation_dict"]
                      [item]["pulse_info"][0]["duration"])
            sched_time += compiled_sched["operation_dict"][item]["pulse_info"][0]["duration"]
        print("schedule time : {}s".format(sched_time))
        shots = compiled_sched['repetitions']
        print("shots : {}".format(shots))
        total_schedule = shots*sched_time
        print("total schedule time : {}s".format(total_schedule))
        # for sched_item in compiled_sched.timing_constraints:
        #    print(sched_item)
        #    print(sched_item['abs_time'])
        #    sched_time += sched_item['abs_time']
        #self.hardware_runtime['schedule'] += sched_time * 1e9 * self.shots
        #self.hardware_runtime["compile"] += comp_stop - comp_start
        # simulation
        if self.simulate_res:
            meas = self._simulated_run(sched, backend)
            thr_meas = self.threshold_meas(meas, backend.mod_threshold["qrm0"])

        else:
            post = 0
            thr_meas = 0

        start_job_time = time.time()
        # run schedule
        backend.ic.prepare(compiled_sched)


        start_time, res = timer(backend.ic.start)
        wait_time, res = timer(backend.ic.wait_done)
        print("start : {}s \nwaiting : {}s".format(start_time, wait_time))

        """
        time_dict = {"compile": comp_stop - comp_start,
                     "running": run_time,
                     "post_processing": post,
                     "simulation": sim_time,
                     "schedule": sched_time}
        """
        stop_job_time = time.time()
        job_time = stop_job_time - start_job_time
        time_dict = {"total_time":job_time, "schedule":total_schedule,
                     "running": start_time+wait_time}

        return {"counts": thr_meas, "time_per_step": time_dict}

    def threshold_meas(self, sim_meas, thr):
        """
        Software solution to threshold the measurement points. In the future,
        this is to be replaced with a hardware intgrated function.
        """
        measures = []
        for mod in sim_meas:
            for seq in sim_meas[mod]:
                qubits = [sd.q_threshold(q, thr) for q in sim_meas[mod][seq]]
                qubits = [str(q) for q in qubits]
                measures.append(qubits)
        measures = np.array(measures)
        measures = np.transpose(measures)
        measures = ["".join(meas) for meas in measures]
        result = dict(collections.Counter(measures))
        return result


    def _simulated_run(self, sched, backend):
        """
        Simulates measurement points from a quantify schedule using a
        pre-defined quantum simulator.
        """
        # simulation of results
        sim_start = time.time_ns()
        qasm_str = qasm.cast_to_QASM(sched, backend.accessable_qubits)
        sim_result = sim.simulate_results(qasm_str, shots=self.shots)
        sim_meas = sd.simulate_qi_res(sim_result)
        self.hardware_runtime['simulation'] += time.time_ns() - sim_start
        """
        plot_index = "2{}".format(len(sim_meas))
        if self.plot:
            i = 0
            for mod in sim_meas:
                j = 0
                for seq in sim_meas[mod]:
                    j += 1
                    sub_index = int(plot_index + str(j + 2 * i))
                    plt.subplot(sub_index)
                    plt.plot(
                        np.real(
                            sim_meas[mod][seq]), np.imag(
                            sim_meas[mod][seq]), '.')
                i += 1
        """
        return sim_meas

    def _play_simulated_waveforms(self, simulated_results):
        """
        Function to play simualted results as waveforms on a qblox device,
        in order to emulate a quantum device signal.
        """
        return 0

    