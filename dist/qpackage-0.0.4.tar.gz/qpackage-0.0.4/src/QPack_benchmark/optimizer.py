#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 14:33:26 2022

Classical optimizer for QPack benchmark
@author: koen
"""

from math import pi
import scipy.optimize as opt
from QPack_benchmark import cost_library as cl

class optimize():
    def __init__(self):
        self.time_res = {"quantum_runtime" : [], "time_per_step":{}, "iterations":0}
        

    def __function_select(self, params, q_func, graph, p, backend, shots, opt_mode):
        """
        Select problem function. Runs the QAOA algorithm and cost function
        post-processing for selected problem.
        """
        # select quantum language for QAOA
        backend_name = backend.configuration().backend_name
        
        if "ibm" in backend_name or "simulator" in backend_name:
            import QAOA_qiskit as QAOA
        else:
            import QAOA_quantify as QAOA

        inverted=False
        
        # Run and post-process max cut problem
        if q_func == 'mcp':
            job, times = QAOA.qaoa_mcp(params, graph, p, backend, shots)
            cost_func = cl.mcp
            if opt_mode == "minimize":
                # mcp needs to be maximized, cost is inverted for minimizer
                inverted = True
                
        # Run and post-process dominating set problem
        elif q_func == 'dsp':
            job, times = QAOA.qaoa_dsp(params, graph, p, backend, shots)
            cost_func = cl.dsp
            
        # Run and post-process traveling salesman problem
        elif q_func == 'tsp':
            job, times = QAOA.qaoa_tsp(params, graph, p, backend, shots)
            cost_func = cl.tsp
        
        self.time_res["quantum_runtime"].append(times)
        for key in job["time_per_step"]:
            if key in self.time_res["time_per_step"]:
                self.time_res["time_per_step"][key] += job["time_per_step"][key]
            else:
                self.time_res["time_per_step"][key] = 0
        self.time_res["iterations"] += 1
            
        #self.time_res["time_per_step"].append(job["time_per_step"])
        return cost_func(job, graph)


    def shgo(self, init_param, graph, p, q_func, backend, shots):
        """
        Simplicial homology global optimization (SHGO) is a bounded minimization
        optimizer.
        """
        
        bounds = [(0, pi), (0, 2 * pi)] #!!!
        res = opt.shgo(self.__function_select, bounds, args=(q_func, graph, p, backend, shots, "minimize"),
                       options={'ftol': 1e-10})
        print(self.time_res)
        return {"fun" : res.fun, "result" : res.x,
                "function evaluations" : res.nfev, "optimizer iterations" : res.nit}
